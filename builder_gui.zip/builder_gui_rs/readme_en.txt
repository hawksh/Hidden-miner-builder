Algo - can be left blank. It will default on cryptonight v7 or:
cryptonight     (v7)
cryptonight/0   (�������)
cryptonight/1
cryptonight/xtl
cryptonight/msr
cryptonight/xao
cryptonight/rto
cryptonight-lite
cryptonight-lite/0
cryptonight-lite/1
cryptonight-lite/ipbc
cryptonight-heavy
cryptonight-heavy/xhv
cryptonight-heavy/tube

Loggers.
We create an "invisible image" on https://iplogger.com/, get the address "https://2no.co/16Sxt7", 
copy "16Sxt7" and paste it into the desired logger.

Bot.
Download the video on YouTube, get a link, for example https://www.youtube.com/watch?v=32LuSdijOsc and enter the bot address "32LuSdijOsc"
We choose the time for checking the commands and that's all.

List of bot commands:
_download link - the bot downloads the file from the link and then deletes it in 10 seconds. If the file does not come out to be removed,
it hides it.

_run link - similar to the top command, but after downloading it launches the downloaded file and hides it. Without deleting.
(Checking the format of the link, loading only the correct link and files with the extension exe)

_rdel link - similar to the top two commands. But after starting the file it waits 20 seconds and deletes it after 20 seconds.
If the file can not be deleted, it hides it. (check the format of the link, loads only on the correct link and files with the extension exe)

_update link - this command stops the mining and starts downloading the build update. After the download, the update is started,
the bot is turned off and the assembly is updated. Therefore, all infected machines can be upgraded to a fresh build version.
(only works when the correct format of the link and with the correct (exe) extension of the file)

_delete - cleans out all the "garbage" that remains or can remain after using the top commands. Recommended to use after working with the bot.

* Commands are entered in the description for the video. Not in the comments to the video, but in the description.
[Precautions] "Link" - in this place there should be a direct link to the downloadable file or to a new version of the assembly. 
(a straight line is when the download starts immediately, without any "download" buttons, etc.)

del.bat - to remove the installed build.

For more experienced users.
In the \pucker\ directory, editing the start.bat, start2.bat, and SystemCheck.xml files can change the installation directory and name.
Similarly, with new_update.bat, new_update2.bat, respectively, that is used when building the "update".

You can try to crypt \mine32\start.exe and \mine64\start.exe, this will positively affect the build detection. (but not every cryptor is suitable, check work performance)
Also, the installer itself can try to crypt. (start.exe or run.exe)